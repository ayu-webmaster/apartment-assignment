module.exports = [
  { _id: "D7Ku4rs69NpB7NMWnZzwDN5", firstName: "Homelike", lastName: "Admin", role: "admin" },
  { _id: "RmwtVzRTJWvCN6MWWRHZvjM", firstName: "Owner", lastName: "Numer1", role: "landlord" },
  { _id: "fX89GctXRq99tB4nMTVTadx", firstName: "Owner", lastName: "Numer2", role: "landlord" },
  { _id: "4X2Lug8JgTq6zawTAHBJ66L", firstName: "Owner", lastName: "Numer3", role: "landlord" },
  { _id: "54GFhpADEMWGcMpyyDK2a8k", firstName: "User", lastName: "Numer1", role: "user" },
  { _id: "FnxZ4MPCp93YEAyTDvkzDkp", firstName: "User", lastName: "Numer2", role: "user" },
];