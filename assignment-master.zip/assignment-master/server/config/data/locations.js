module.exports = [
  { _id: "5b62B540BcFF044ffA169f60", active: true, title: "Berlin", country: "4X2Lug8JgTq6zNMWnZzwDN5" },
  { _id: "507F191e810c19729De860eA", active: true, title: "Cologne", country: "4X2Lug8JgTq6zNMWnZzwDN5" },
  { _id: "53DC98133bAb79000034E25a", active: true, title: "Stuttgart", country: "4X2Lug8JgTq6zNMWnZzwDN5" }
];