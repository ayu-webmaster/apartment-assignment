const sha256 = require('sha256');

module.exports = [
  { _id: "2RPaLtQSaZsBtn5EFKM6S3F", owner: "D7Ku4rs69NpB7NMWnZzwDN5", email: "admin@assignment.cc", password: sha256('testPWD') },
  { _id: "hRPEGtRVBRfKN9BvuYEPTwa", owner: "RmwtVzRTJWvCN6MWWRHZvjM", email: "owner.o1@assignment.cc", password: sha256('testPWD') },
  { _id: "dJqcRuhKjugVVYQTN59qZut", owner: "fX89GctXRq99tB4nMTVTadx", email: "owner.o2@assignment.cc", password: sha256('testPWD') },
  { _id: "8s2zWks6fTBapkbLgrcW4n8", owner: "4X2Lug8JgTq6zawTAHBJ66L", email: "owner.o3@assignment.cc", password: sha256('testPWD') },
  { _id: "t6dmDBE4GsqWbTrwKWBty9W", owner: "54GFhpADEMWGcMpyyDK2a8k", email: "user.u1@assignment.cc", password: sha256('testPWD') },
  { _id: "42T5wTxKUwTjTnW4hyZMcvZ", owner: "FnxZ4MPCp93YEAyTDvkzDkp", email: "user.u2@assignment.cc", password: sha256('testPWD') },
];